'use strict';
// Contraintes :

// - N'importe quel attr & n sous niveau
// - Fonction parser pour chaque attr (facultative)
// - Fonction de comparaison (facultative)

// Birthday_date, first_name



var Coll = Backbone.Collection.extend({
  megaSort: function(attr, options){
    options = options || {};

    /**
     * @param  {Mixed} value from model a
     * @param  {Mixed} value from model b
     * @return {Number} -1 if a < b, 0 if a == b, 1 if a > b
     */
    var comparator = _.isFunction(options.comparator) ?
                        options.comparator :
                        function(a, b){return a -b;};

    /**
     * Return a comparable value from the raw model attribute value
     * @type {Mixed}
     */
    var getValue   = _.isFunction(options.getValue) ?
                        options.getValue :
                        function(val){return val;};

    /**
     * @param  {Backbone.Model} model
     * @param  {String} attr
     * @return {Mixed}  attribute or sub-attribute value
     */
    function getAttribute(model, attr){
      attr = attr.split('.');

      return attr.reduce(function(cursor, attribute){
        return (_.isObject(cursor) ? cursor : {})[attribute];
      }, model.attributes);
    }

    this.comparator = function(a, b){
      return comparator(getValue(getAttribute(a, attr)), getValue(getAttribute(b, attr)));
    };

    return this.sort();
  }
})

var c = new Coll();

c.megaSort('first_name', {
  comparator: function(a, b){
    return a.localCompare(b);
  }
});

c.megaSort('hometown_location.city', {
  comparator: function(a, b){
    return a.localCompare(b);
  }
});

c.megaSort('birthday_date', {
  getValue: function(rawValue){
    return rawValue !== null ? new Date(rawValue).getTime() : 0;
  }
});


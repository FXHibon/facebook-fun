'use strict';

FbFriends.Friends = Backbone.Collection.extend({
  model: FbFriends.Friend,

  initialize: function(){
    this.sortAttribute = 'first_name';
  },

  autoSort: function(){
    var NUMBER_OPTIONS = {
        getValue: function(rawValue){
          return parseInt(rawValue, 10) || Number.MIN_VALUE;
        },
        comparator: function(a, b){
          return b-a;
        }
      };

    var visitors = {
      'birthday_date': {
        getValue: function(rawValue){
          return rawValue ? +new Date(rawValue) : Number.MAX_VALUE;
        }
      },

      'friend_count': NUMBER_OPTIONS,
      'wall_count': NUMBER_OPTIONS
    };

    this.megaSort(this.sortAttribute, visitors[this.sortAttribute]);
  },

  setSortAttribute: function(attr){
    this.sortAttribute = attr;
  },

  /**
   * [filterByFullname description]
   * @param  {String} query
   */
  filterByFullname: function(query){
    var coll = new FbFriends.Friends(this.filter(function(friendModel){
      return friendModel.fullNameContains(query);
    }));

    coll.setSortAttribute(this.sortAttribute);
    coll.autoSort();
    this.trigger('reset', coll);
  },

  megaSort: function(attr, options){
    options = options || {};

    function defaultComparator(a, b){
      return _.isString(a) && _.isString(b) ? a.localeCompare(b) : a-b;
    }

    /**
     * @param  {Mixed} value from model a
     * @param  {Mixed} value from model b
     * @return {Number} -1 if a < b, 0 if a == b, 1 if a > b
     */
    var comparator = _.isFunction(options.comparator) ? options.comparator : defaultComparator;

    /**
     * Return a comparable value from the raw model attribute value
     * @type {Mixed}
     */
    var getValue   = _.isFunction(options.getValue) ?
                        options.getValue :
                        function(val){return val;};

    /**
     * @param  {Backbone.Model} model
     * @param  {String} attr
     * @return {Mixed}  attribute or sub-attribute value
     */
    function getAttribute(model, attr){
      attr = attr.split('.');

      return attr.reduce(function(cursor, attribute){
        return (_.isObject(cursor) ? cursor : {})[attribute];
      }, model.attributes);
    }

    this.comparator = function(a, b){
      return comparator(getValue(getAttribute(a, attr)), getValue(getAttribute(b, attr)));
    };

    return this.sort();
  },

  /**
   * [getSexRepartition description]
   * @return {Object} e.g. {male: X, female: Y, unknown: Z}
   */
  getSexRepartition: function(){
    return this.countBy('sex');
  },

  getAttributes: function(){
    var attrs = this.map(function(model){
      return Object.keys(model.attributes).filter(function(key){
        var val = model.attributes[key];
        return _.isString(val) || _.isNumber(val);
      });
    });

    attrs = _.flatten(attrs);
    attrs = _.uniq(attrs);
    return attrs;
  }
});

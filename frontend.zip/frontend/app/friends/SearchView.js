'use strict';

FbFriends.SearchView = Backbone.View.extend({
  events:{
    'keyup #search-query': 'search',
    'change select': 'sort',
  },

  initialize: function(options){
    _.extend(this, options);
    this.friends.on('reset', this.render, this);
  },

  searchValue:'',
  search: function(event){
    if(event && event.target && event.target.value){
      this.searchValue = event.target.value;
    }
    this.friends.filterByFullname(this.searchValue);
  },

  sort: function(event){
    this.friends.setSortAttribute(event.target.value);
    this.search();
  },

  render: function(){
    this.$el.find('#attributes-container').html(this.tmpl({attrs: this.friends.getAttributes()}));
  }
});

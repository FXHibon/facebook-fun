'use strict';

FbFriends.ProfilesView = Backbone.View.extend({
  initialize: function(options){
    _.extend(this, options);
    this.friends.on('reset', this.renderProfiles, this);
  },

  renderProfiles: function(coll){

    var html = coll.map(function(friendModel){
      return this.tmpl({
        name: friendModel.get('first_name'),
        surname: friendModel.get('last_name'),
        pictureUrl: friendModel.get('pic_small'),
        birthday_date: friendModel.get('birthday_date'),
        friend_count: friendModel.get('friend_count')
      });
    }, this).join('\n');

    this.$el.find('#profiles').empty().append(html);
    this.$el.find('#statistics').empty().append(JSON.stringify(coll.getSexRepartition()));
  }
});
